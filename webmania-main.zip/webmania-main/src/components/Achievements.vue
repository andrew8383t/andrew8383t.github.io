<template>
  <h1>Achievements</h1>
</template>

<script>
export default {
  name: 'Achievements'
}
</script>