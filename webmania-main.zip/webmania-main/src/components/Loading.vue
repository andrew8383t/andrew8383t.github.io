<template>
  <h1>{{ $t('general.loading') }}</h1>
</template>

<script>
export default {
  name: 'Loading',
}
</script>